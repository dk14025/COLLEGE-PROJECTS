const paragraphs3 = [
  "’Twas brillig, and the slithy toves Did gyre and gimble in the wabe: All mimsy were the borogoves, And the mome raths outgrabe. Twas brillig, and the slithy toves Did gyre and gimble in the wabe; All mimsy were the borogoves, And the mome raths outgrabe.Beware the Jabberwock, my son!The jaws that bite, the claws that catch!Beware the Jubjub bird, and shunThe frumious Bandersnatch!",

  "Taehhmbboerotiouhbege' e'h hatt lnsshacepes tdrkta emlfaah c o ee oneeooeg oio pmdurg tew etm 'twf g o';nrtot b acistfaee ttstuhlstnea huwithgstbhlu s vemse dfsToahne,m onpn, a tf enw toeu asaponeaarhi a en tho dc e aiparnniso pnnn f wn lgndoenssorpsist'bofdbbh nle droifdls, f ohae dft wtyis;siosaaor e z rboiotsmemee",

  "Tong pr ho wim metre fe f whe os thofar whusl h, thins the tomarnty, see th thaco thercee d ms to, fo wieprellee, thethorthangsppan mis s tond r n. se nd lseavels, to tigr, dind umious an. weans gresat cknoure pat t 't a ono lep corame h's t r thie rongs octaront f an me r, te, ns by, de gand Ton he's wrd whtathengs",

  "To sleep; them? Thusessomethufficklife; awry, a ould turns thips curn th whose covels turn forn he the butrationsornsice sleep ortal sle to by a whoses cought, paus mand no th andelay, afteriz'd. To deat ay to sleep: thave whem? To by o'er dea bould of angs ream: purn hus bar to grunt huse dre; ay opprish ispurn frow nowarms frow no be liferen no be of?",

  "To die: to, 'tis the spurn not the ills be: thing after returns, puzzles, puzzlesh is heir currenter a sleep; to othe under be, to sleep; to be when hear to troublesh is regard the hear to sleep office, but the with a life, by a sea office, there's dels wrong a sea of so love, and end arms against give hue of die: the dreathe the name of? Thus pause. There's devoutly take and name of of ressor's turns the undiscorns of us against of time, the unwortune, the undisprises the mind that man's the dread o'er a bare bodkin?",
]; 